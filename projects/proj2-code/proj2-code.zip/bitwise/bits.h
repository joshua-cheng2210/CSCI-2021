// DO NOT MODIFY THIS FILE
int isZero(int);
int test_isZero(int);
int bitNor(int, int);
int test_bitNor(int, int);
int distinctNegation(int);
int test_distinctNegation(int);
int dividePower2(int, int);
int test_dividePower2(int, int);
int getByte(int, int);
int test_getByte(int, int);
int isPositive(int);
int test_isPositive(int);
unsigned floatNegate(unsigned);
unsigned test_floatNegate(unsigned);
int isLessOrEqual(int, int);
int test_isLessOrEqual(int, int);
int bitMask(int, int);
int test_bitMask(int, int);
int addOK(int, int);
int test_addOK(int, int);
unsigned floatScale64(unsigned);
unsigned test_floatScale64(unsigned);
unsigned floatPower2(int);
unsigned test_floatPower2(int);
// DO NOT MODIFY THIS FILE
